<?php
declare(strict_types=1);

/*
| UMA AI CONFIG — SHAKTI PANCHANG
| Copy this file to config.php on the server only.
| Never commit config.php and never put these keys in the APK.
| Same keys as shakti-business/bhavya/v1/config.php can be reused.
|
| Priority: Grok -> Gemini -> OpenRouter -> app's local engine
*/

$XAI_API_KEY = 'PASTE_YOUR_XAI_API_KEY_HERE';
$XAI_MODEL = 'grok-4';
$XAI_ENABLED = true;

$GEMINI_API_KEY = 'PASTE_YOUR_GEMINI_API_KEY_HERE';
$GEMINI_MODEL = 'gemini-2.5-flash';
$GEMINI_ENABLED = true;

$OPENROUTER_API_KEY = 'PASTE_YOUR_OPENROUTER_KEY_HERE';
$OPENROUTER_MODEL = 'openrouter/free';
$OPENROUTER_ENABLED = true;

$UMA_TIMEOUT_SECONDS = 22;
$UMA_MAX_INPUT_LENGTH = 12000;
$UMA_MAX_MESSAGES = 8;
$UMA_MAX_OUTPUT_TOKENS = 1200;
